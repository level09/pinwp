=== Simple Social - Sharing Widgets & Icons ===
Contributors: none
Requires at least: 1
Tags: bookmark, bookmarking, bookmarks, button, buzz, del.icio.us, Digg, e-mail, email, Facebook, google, google buzz, icon, icons, image, images, links, myspace, page, pages, plugin, Post, posts, Reddit, save, seo, Share, sharethis, sharing, social, social bookmarking, social bookmarks, statistics, stats, stumbleupon, technorati, twitter, widget
Tested up to: 3.0.1
Stable tag: 0.2

Adds a set of cool icons and widgets at the end of your post for your readers to share.

== Description ==

This plugin adds a set of cool icons and widgets at the end of your post for your readers to share. Widgets are Twitter and Facebook. It supports large icons and small icons.

== Installation ==

1. Upload `simple-social-sharing-widgets-icons` folder to your WP plugin folder `/wp-content/plugins/` directory
2. The path must look like this: `/wp-content/plugins/simple-social-sharing-widgets-icons/`
3. Activate the plugin through the 'Plugins' menu in WordPress admin
4. You are ready, check the widgets and icons after your posts.
5. To make changes, go to Settings, Simple Social Icons.

Thanks for installing!

== Screenshots ==

1. Large set of widgets & icons
2. Small set of widgets & icons
3. Settings Page